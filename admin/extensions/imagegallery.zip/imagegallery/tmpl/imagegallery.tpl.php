<ul class="gallery gal[FIELD_ID]">
    [LINES]
</ul>

