<div id="cel_[VALUE]">
    <span class="title">[TITLE]</span>
    <span class="value">[FIELD_ID]</span>
</div>
